from django.urls import path
from .views import HomeView
from django.views.generic import TemplateView

urlpatterns = [
    path('', HomeView.as_view(), name='home'),
    path('crear/', TemplateView.as_view(template_name='blog/crear_reseña.html'), name='crear_reseña'),
    path('juegos/', TemplateView.as_view(template_name='blog/descargar_juegos.html'), name='descargar_juegos'),
]
