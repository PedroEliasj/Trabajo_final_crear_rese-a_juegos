from django.views.generic.edit import CreateView
from django.urls import reverse_lazy
from .models import Juegos

class HomeView(CreateView):
    model = Juegos
    template_name = 'blog/crear_reseña.html'
    fields = ['titulo', 'autor', 'categoria', 'descripcion', 'imagen']
    success_url = reverse_lazy('home')
    
from django.views.generic import ListView  # nueva importación

class ListaJuegosView(ListView):
    model = Juegos
    template_name = 'blog/lista_juegos.html'
    context_object_name = 'juegos'
