from django.contrib import admin
from django.urls import path, include
from blog import views
from django.shortcuts import render, get_object_or_404
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('blog.urls')),
    path('articulo/<int:pk>/', views.detalle_articulo, name='detalle_articulo'),
]

# Agregado necesario para servir imágenes en desarrollo
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
