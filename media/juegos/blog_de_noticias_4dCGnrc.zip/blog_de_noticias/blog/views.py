from django.shortcuts import render, redirect
from .models import Articulo
from .forms import ArticuloForm

# Vista para mostrar los artículos
def inicio(request):
    articulos = Articulo.objects.all().order_by('-fecha_publicacion')
    return render(request, 'blog/inicio.html', {'articulos': articulos})

# Vista para crear artículos
def crear_articulo(request):
    if request.method == 'POST':
        form = ArticuloForm(request.POST, request.FILES)
        if form.is_valid():
            articulo = form.save(commit=False)
            articulo.autor = request.user  # Solo si el usuario está logueado
            articulo.save()
            return redirect('inicio')
    else:
        form = ArticuloForm()
    return render(request, 'blog/publicar.html', {'form': form})

from django.shortcuts import get_object_or_404

def detalle_articulo(request, pk):
    articulo = get_object_or_404(Articulo, pk=pk)
    return render(request, 'blog/detalle.html', {'articulo': articulo})

